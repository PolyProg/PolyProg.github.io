// Sample library
// Note that the real library is different than this!
/*
   In this sample library, we use the following functions:
   First testcase (straight line from (1, 0) to (-2, 0) ):
   x(t) = 2*t^2 - 5*t + 1
   y(t) = 0

   Second testcase (circle of radius 1 around the origin):
   x(t) = cos(2*pi*t)
   y(t) = sin(2*pi*t)
*/

import java.util.Set;
import java.util.HashSet;

class Boomerang
{
	//You may call the following 6 functions with at most 33 different
	//values of t:

	// Returns the X coordinate of the position of the boomerang
	//    at time t (0<=t<=1)
	public static double positionx(double t){
		queried.add(t);
		if(t<-1e-8 || t > 1+1e-8)
		{
			System.out.printf("t must be in range 0-1. (%.20f)\n", t);
			System.exit(3);
		}
		if(queries_left() < 0)
		{
			System.out.println("Too many queries. Terminating program.");
			System.exit(1);
		}
		if(testcase==0)
			return 2*t*t-5*t+1;
		else
			return Math.cos(2*Math.PI*t);
	}
	// Returns the Y coordinate of the position of the boomerang
	//    at time t (0<=t<=1)
	public static double positiony(double t){
		queried.add(t);
		if(t<-1e-8 || t > 1+1e-8)
		{
			System.out.printf("t must be in range 0-1. (%.20f)\n", t);
			System.exit(3);
		}
		if(queries_left() < 0)
		{
			System.out.println("Too many queries. Terminating program.");
			System.exit(1);
		}
		if(testcase==0)
			return 0.0;
		else
			return Math.sin(2*Math.PI*t);
	}
	// Returns the X coordinate of the speed vector of the boomerang
	//    at time t (0<=t<=1)
	public static double speedx(double t){
		queried.add(t);
		if(t<-1e-8 || t > 1+1e-8)
		{
			System.out.printf("t must be in range 0-1. (%.20f)\n", t);
			System.exit(3);
		}
		if(queries_left() < 0)
		{
			System.out.println("Too many queries. Terminating program.");
			System.exit(1);
		}
		if(testcase==0)
			return 4*t-5;
		else
			return -2*Math.PI*Math.sin(2*Math.PI*t);
	}
	// Returns the Y coordinate of the speed vector of the boomerang
	//    at time t (0<=t<=1)
	public static double speedy(double t){
		queried.add(t);
		if(t<-1e-8 || t > 1+1e-8)
		{
			System.out.printf("t must be in range 0-1. (%.20f)\n", t);
			System.exit(3);
		}
		if(queries_left() < 0)
		{
			System.out.println("Too many queries. Terminating program.");
			System.exit(1);
		}
		if(testcase==0)
			return 0.0;
		else
			return 2*Math.PI*Math.cos(2*Math.PI*t);
	}
	// Returns the X coordinate of the acceleration vector of the boomerang
	//    at time t (0<=t<=1)
	public static double accelerationx(double t){
		queried.add(t);
		if(t<-1e-8 || t > 1+1e-8)
		{
			System.out.printf("t must be in range 0-1. (%.20f)\n", t);
			System.exit(3);
		}
		if(queries_left() < 0)
		{
			System.out.println("Too many queries. Terminating program.");
			System.exit(1);
		}
		if(testcase==0)
			return 4.0;
		else
			return -4*Math.PI*Math.PI*Math.cos(2*Math.PI*t);
	}
	// Returns the Y coordinate of the acceleration vector of the boomerang
	//    at time t (0<=t<=1)
	public static double accelerationy(double t){
		queried.add(t);
		if(t<-1e-8 || t > 1+1e-8)
		{
			System.out.printf("t must be in range 0-1. (%.20f)\n", t);
			System.exit(3);
		}
		if(queries_left() < 0)
		{
			System.out.println("Too many queries. Terminating program.");
			System.exit(1);
		}
		if(testcase==0)
			return 0.0;
		else
			return -4*Math.PI*Math.PI*Math.sin(2*Math.PI*t);
	}


	// Has the state at time t (0<=t<=1) already been queried in this
	//    testcase?
	public static boolean already_queried(double t){
		return queried.contains(t);
	}
	// Returns the number of new queries you are allowed to make in this
	//    testcase
	public static int queries_left(){
		return max_queries - queried.size();
	}


	// Provide your answer (average length of the norm of the speed vector of the boomerang)
	//    to this testcase, and go to the next testcase.
	//    This function will terminate the program after the last testcase.
	public static void answer(double s)
	{
		if(s<0)
		{
			System.out.println("Speed cannot be negative. Terminating.");
			System.exit(-1);
		}
		double correct=0;
		switch(testcase)
		{
			case 0: correct=3.0; break;
			case 1: correct=2*Math.PI; break;
		}
		System.out.println("Your answer: "+s);
		System.out.println("Correct answer: "+correct);
		System.out.println("Relative error: "+ Math.abs(s-correct)/correct);
		System.out.println();

		testcase++;
		queried.clear();
		if(testcase==2)
		{
			System.out.println("Program exited normally");
			System.exit(0);
		}
	}


	private static final int max_queries=33;
	private static int testcase = 0;
	private static Set<Double> queried = new HashSet<Double>();
}
