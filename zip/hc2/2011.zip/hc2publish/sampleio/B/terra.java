import java.util.Scanner;

class Terra
{
	public static final int MAXC = 50;
	public static final int MAXP = 8;
	public static final int MAXV = 3;

	public static int number_cities()
	{
		read_input();
		return C;
	}

	public static int number_properties()
	{
		read_input();
		return P;
	}

	public static void read_catalog(int desc[][])
	{
		int c, p;
		read_input();
		for (c=0; c<C; c++)
		{
			for (p=0; p<P; p++)
				desc[c][p] = cityDesc[c][p];
		}
	}

	public static boolean heidi_askQuestion(int yourP, int yourV)
	{
		read_input();
		assert(yourP>0 && yourP<=P && yourV>0 && yourV<=3);
		questionCnt++;
		
		/* debug information for user*/
		System.out.printf("You ask p[%2d] ?= %d  -  Heidi says %d\n",yourP,yourV,(cityDesc[cityIndex][yourP-1]==yourV)?1:0);

		return cityDesc[cityIndex][yourP-1]==yourV;
	}

	public static void heidi_tellCity(int yourC)
	{
		read_input();
		assert(yourC>0 && yourC<=C);

		if (yourC-1!=cityIndex)
			System.out.printf("WRONG ANSWER : You think Heidi is in city %2d, but she is in city %2d !\n",yourC,cityIndex+1);
		else	
			System.out.printf("ACCEPTED : You asked %2d questions and found the correct city!\n",questionCnt);
		System.exit(0);
	}

	private static void read_input()
	{
		int ci, p, cc;
		if(readinput_done)
			return;
		readinput_done=true;

		cc = rand()%MAXC + 1;
		P = rand()%MAXP + 1;

		/*Generate the properties of each city*/
		for(ci=0;ci<cc;++ci)
		{
			int d;
			boolean ok=true;

			/*Random properties*/
			for(p=0;p<P;++p)
			{
				cityDesc[C][p] = rand()%MAXV + 1;
			}

			/*Make sure the properties are unique*/
			for(d=0;d<C;++d)
			{
				boolean same=true;
				for(p=0;p<P;++p)
				{
					if(cityDesc[C][p]!=cityDesc[d][p])
					{
						same=false;
						break;
					}
				}

				if(same)
				{
					ok=false;
					break;
				}
			}

			if(ok)
			{
				C++;
				System.out.printf("City %2d has property values: ", C);
				for (p=0; p<P; p++)
					System.out.printf("%d ",cityDesc[C-1][p]);
				System.out.printf("\n");
			}
		}


		/*Determine starting city*/
		cityIndex = (rand()%C);

		System.out.printf("Heidi will be in city %2d with property values \n",cityIndex+1);
		for (p=0; p<P; p++)
			System.out.printf("%d ",cityDesc[cityIndex][p]);
		System.out.printf("\n");
		questionCnt = 0;
	}

	private static int rand()
	{
		final int a = 1103515245;
		final int c = 12345;

		seed = a*seed + c;

		return seed&0x3FFFFFFF;
	}

	private static int seed=1;
	private static int C;
	private static int P;
	private static int cityDesc[][] = new int[MAXC][MAXP];
	private static int questionCnt;
	private static int cityIndex;
	private static boolean readinput_done=false;
}



