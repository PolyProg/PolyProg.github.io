#include "terra.h"

int main(int argc, char** argv)
{
	int CC, PP;
	int cityDesc[MAXC][MAXP];
	int p, c;

	CC = number_cities();
	PP = number_properties();
	read_catalog(cityDesc);

	for(c=1;c<=CC;++c)
	{
		int ok=1;
		for(p=1;p<=PP;++p)
		{
			if(!heidi_askQuestion(p, cityDesc[c-1][p-1]))
				ok=0;
		}
		if(ok)
			heidi_tellCity(c);
	}
	return 0;
}
