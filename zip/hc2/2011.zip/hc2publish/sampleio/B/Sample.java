
public class Sample
{
	public static void main(String args[])
	{
		int CC = Terra.number_cities();
		int PP = Terra.number_properties();

		int[][] cityDesc = new int[CC][PP];

		Terra.read_catalog(cityDesc);

		for(int c=1;c<=CC;++c)
		{
			boolean ok=true;
			for(int p=1;p<=PP;++p)
			{
				if(!Terra.heidi_askQuestion(p, cityDesc[c-1][p-1]))
					ok=false;
			}
			if(ok)
				Terra.heidi_tellCity(c);
		}
	}
}
