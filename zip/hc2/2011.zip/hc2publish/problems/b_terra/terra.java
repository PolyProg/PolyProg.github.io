
import java.util.Scanner;

class Terra
{
	private static final int INFQ = 120;
	public static final int MAXC = 50;
	public static final int MAXP = 8;
	public static final int MAXV = 3;
	private static final int NSTATES = (1<<(MAXP*MAXV));



	private static boolean input_done=false;
	private static int C, P;								/* C is the number of cities, P the number of properties*/
	private static int cities[] = new int[MAXC];						/* description of the cities*/
	private static byte minQ[] = new byte[NSTATES];						/* minimum number of questions from a given state till answer*/
	private static int state;								/* the actual state*/
	private static int minQuest;				/* minimum number of questions and user's number of questions*/
	private static int userQuest=0;				/* minimum number of questions and user's number of questions*/
	private static int judgeTime=0;						/* total time used by judge (in us)*/
	private static int cityDesc[][] = new int[MAXC][MAXP];

	private static byte max(byte a, byte b)
	{
		if(a>b)
			return a;
		return b;
	}
	private static void read_input()
	{
		int c, p, i;
		if(input_done)
			return;
		input_done=true;

		try
		{
			Scanner sc = new Scanner(System.in);

			/* read travel book*/
			C = sc.nextInt();
			P = sc.nextInt();
			for (c=0; c<C; c++)
				for (p=0; p<P; p++)
					cityDesc[c][p] = sc.nextInt();
			minQuest = sc.nextInt();
		}
		catch(Exception e)
		{
			System.out.printf("Error while reading input\n");
			System.exit(1);
		}
				
		/* encode cities*/
		for (c=0; c<C; c++)
		{
			cities[c]=0;
			for (p=0; p<P; p++)
				cities[c] |= 1<<(p*MAXV+cityDesc[c][p]-1);
		}
		
		/* reset the minimal number of questions*/
		for (i=0; i<(1<<(P*MAXV)); i++)
			minQ[i] = INFQ;
		state = (1<<(P*MAXV))-1;

	}

	public static int number_cities()
	{
		read_input();
		return C;
	}

	public static int number_properties()
	{
		read_input();
		return P;
	}

	public static void read_catalog(int desc[][])
	{
		int c, p;
		read_input();
		for (c=0; c<C; c++)
		{
			for (p=0; p<P; p++)
				desc[c][p] = cityDesc[c][p];
		}
	}

	/* counts the number of bits set in 'n' */
	private static int bit_count (int n)
	{
		n = n - ((n >> 1) & 0x55555555);
		n = (n & 0x33333333) + ((n >> 2) & 0x33333333);
		return (((n + (n >> 4)) & 0xF0F0F0F) * 0x1010101) >> 24;
	}

	/* counts the number of remaining candidate cities in state 'state' */
	private static int city_count(int state)
	{
		int nCities=0,i=0;
		for (i=0; i<C; i++)
			nCities += (bit_count(cities[i]&state)==P)?1:0;
		return nCities;
	}

	/* finds the best question to ask in state 'cState' */
	private static void find_clever_question(int cState)
	{
		int tState, fState, p, v;
			
		/* do we have a single candidate left?*/
		if (minQ[cState]==0 || city_count(cState)<=1)
		{
			minQ[cState] = 0;		
			return;
		}
		
		/* try every answer to every value of every property*/
		for (p=0; p<P; p++)
			if (
					(((cState & (1<<(p*MAXV+0)))>0)?1:0) +
					(((cState & (1<<(p*MAXV+1)))>0)?1:0) +
					(((cState & (1<<(p*MAXV+2)))>0)?1:0) > 1)
				for (v=0; v<MAXV; v++)
					if (0!=(cState & (1<<(p*MAXV+v))))
					{
						/* states after answer*/
						tState = cState & ~((1<<(p*MAXV+((v+1)%MAXV))) | (1<<(p*MAXV+((v+2)%MAXV))));
						fState = cState & ~(1<<(p*MAXV+v));
						
						/* count remaining questions if answer is TRUE*/
						if (minQ[tState]==INFQ)
							find_clever_question(tState);
							
						/* quit early if no better than the best so far*/
						if (minQ[tState]+1>=minQ[cState])
							continue;
			
						/* count remaining questions if answer is FALSE*/
						if (minQ[fState]==INFQ)
							find_clever_question(fState);
					
						/* check whether worst answer would still be best option*/
						if (minQ[fState]+1 < minQ[cState])
							minQ[cState] = (byte)(max(minQ[tState],minQ[fState])+1);
					}
	}

	public static boolean heidi_askQuestion(int p, int v)
	{
		long startTime;
		long endTime;
		int tState, fState;
		read_input();
		startTime = System.nanoTime();

		userQuest++;
		p--; v--;
		tState = state & ~((1<<(p*MAXV+((v+1)%MAXV))) | (1<<(p*MAXV+((v+2)%MAXV))));
		fState = state & ~(1<<(p*MAXV+v));
						
		/* count remaining questions if answer is TRUE*/
		if (minQ[tState]==INFQ)
			find_clever_question(tState);
							
		/* count remaining questions if answer is FALSE*/
		if (minQ[fState]==INFQ)
			find_clever_question(fState);
			
		endTime = System.nanoTime();
		judgeTime += (int)((endTime-startTime)/1000);
		
		/* answer s.t. number of emaining questions is maximized, and if tie, number of remaining cities is maximized*/
		if (minQ[tState]>minQ[fState])
		{
			state = tState;
			return true;
		}
		else if (minQ[fState]>minQ[tState])
		{
			state = fState;
			return false;
		}
		else if (city_count(tState)>city_count(fState))
		{
			state = tState;
			return true;
		}
		else
		{
			state = fState;
			return false;
		}
	}

	public static void heidi_tellCity(int userC)
	{
		read_input();
		if (bit_count(cities[userC-1]&state)!=P)
			System.out.printf("WRONG ANSWER, your choice is incorrect\n");
		else if (city_count(state)>1)
			System.out.printf("WRONG ANSWER, solution was not yet unique\n");
		else if (userQuest>minQuest)
			System.out.printf("Correct, but you used %d questions while %d are sufficient\n",userQuest,minQuest);
		else if (userQuest<minQuest)
			System.out.printf("Congrats, you did unexpectedly well! Contact Christian and tell him that his solution is sub-optimal!\n");
		else
		{
			int c, p;
			/*Note that we can't print anything else than the success message in this case.*/
			System.out.printf("ACCEPTED - e6bd0c895f916fcaafb00dfbab5d9f8a\n");
			/*Also print input to make sure the contestants didn't cheat*/
			for(c=0;c<C;++c)
			{
				System.out.printf("/");
				for(p=0;p<P;++p)
					System.out.printf("%d.", cityDesc[c][p]);
			}
			System.out.printf("\n");
			
			System.exit(0);
		}
		System.out.printf("The judge used %5.3fs out of the total time\n",judgeTime/1000000.0);
	}
}




