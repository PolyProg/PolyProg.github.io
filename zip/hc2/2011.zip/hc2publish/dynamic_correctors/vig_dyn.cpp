#include <cstdio>
#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <cctype>
#include <fstream>
#include <cmath>
#include <cstdlib>

using namespace std;

const int RES_ACCEPTED=0;
const int RES_PRESENTATION=1;
const int RES_WRONG=2;
const int RES_RT_ERROR=7;
const int RES_RT_REEVAL=11;

//Remove spaces from a string
string remspace(string a)
{
	string s;
	for(size_t i=0;i<a.length();++i)
		if(isalpha(a[i]))
			s+=tolower(a[i]);
	return s;
}

int main(int argc, char** argv)
{
	//Expected arguments:
	// 1. Real solution: one line per testcase: 0 of impossible 1 for possible
	// 2. Obtained solution
	// 3. Testcase number (1-10)
	// 4. Input
	// 5. Classify (current classification, should be lower/equal to 2)

	if(argc!=6)
	{
		fprintf(stderr, "Usage: %s expected obtained args input classify\n", argv[0]);
		fprintf(stderr, "Got %d args, expected 6\n", argc);
		return RES_RT_REEVAL;
	}


	fstream expected(argv[1]);
	if(!expected)
	{
		fprintf(stderr, "Couldn't open 'expected' %s\n", argv[1]);
		perror("");
		return RES_RT_REEVAL;
	}
	fstream obtained(argv[2]);
	if(!obtained)
	{
		fprintf(stderr, "Couldn't open 'obtained' %s\n", argv[2]);
		perror("");
		return RES_RT_ERROR;
	}
	int testcase = atoi(argv[3]);
	//Ignore 3rd argument
	fstream input(argv[4]);
	if(!input)
	{
		fprintf(stderr, "Couldn't open 'input' %s\n", argv[4]);
		perror("");
		return RES_RT_REEVAL;
	}
	int classify = atoi(argv[5]);

	if(classify > RES_WRONG)
	{
		fprintf(stderr, "Testcase already classified as %d\n", classify);
		return classify;
	}

	//Read solution of candidate
	string t;
	char llang;
	while(1)
	{
		int tc;
		string lang;
		obtained>>tc>>lang;
		getline(obtained, t);
		if(obtained.eof())
		{
			fprintf(stderr, "Didn't find testcase %d\n", testcase);
			return RES_WRONG;
		}
		if(obtained.fail())
		{
			fprintf(stderr, "Incorrectly formatted input line\n");
			return RES_PRESENTATION;
		}

		if(tc == testcase)
		{
			if(lang.size()!=1)
			{
				fprintf(stderr, "Language wrong\n");
				return RES_PRESENTATION;
			}
			llang = tolower(lang[0]);

			if(llang!='e' && llang!='d' && llang!='f')
			{
				fprintf(stderr, "Unknown language\n");
				return RES_PRESENTATION;
			}

			break;
		}
	}

	string tt;
	//Read real solution
	while(1)
	{
		int tc;
		string lang;
		expected>>tc>>lang;
		getline(expected, tt);
		if(expected.eof())
		{
			fprintf(stderr, "Expected: Didn't find testcase %d\n", testcase);
			return RES_RT_REEVAL;
		}
		if(expected.fail())
		{
			fprintf(stderr, "Expected: Incorrectly formatted input line\n");
			return RES_RT_REEVAL;
		}

		if(tc == testcase)
		{
			if(lang.size()!=1)
			{
				fprintf(stderr, "Expected: Language wrong\n");
				return RES_RT_REEVAL;
			}
			char ellang = tolower(lang[0]);

			if(ellang!='e' && ellang!='d' && ellang!='f')
			{
				fprintf(stderr, "Expected: Unknown language\n");
				return RES_RT_REEVAL;
			}

			if(ellang == llang)
				break;
		}
	}

	t = remspace(t);
	tt = remspace(tt);

	if(t.size() != tt.size())
	{
		fprintf(stderr, "Wrong number of characters: obtained %d expected %d\n",
				(int)t.size(), (int)tt.size());
		return RES_PRESENTATION;
	}

	int wrong=0;
	for(size_t i=0;i<tt.size();++i)
	{
		if(tolower(t[i]) != tolower(tt[i]))
			wrong++;
	}

	if(!wrong)
		return RES_ACCEPTED;

	fprintf(stderr, "Wrong answer: %f%% correct\n", wrong*100./tt.size());
	return RES_WRONG;
}
