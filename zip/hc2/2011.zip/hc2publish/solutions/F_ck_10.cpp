/* Boomerang - Solution by Christian Kauth - 09/01/2011
 * -------------------------------------------------------
 * This is a versatile maths problem which allows for very different approaches (geometry, linear algebra, numerical analysis ...) and even physics.
 * 
 * I'll present here a geometric solution, as it can be greatly worked out on paper and pencil, and leaves the computer free for your 
 * team-mates to code something else. Although coding will be quite fast, the analytical solution requires your full concentration!
 * 
 * Given 2 points, we need to find a curve that connects them and whose derivative (speed) and second derivative (acceleration) have specific
 * values. Hence we need to find an equation with 6 degrees of freedom (at least). There is no reason to use more than 6, as we have no
 * further constraints. Additionally the problem has a physical origin, so we can suppose smooth variations rather than drastic transitions.
 *
 * So let's invent a function between these 2 points. My choice : Bezier curves (easy to remember), 5th order obviously.
 *  B(t) = (1-t)⁵P0 + 5t(1-t)⁴P1 + 10t²(1-t)³P2 + 10t³(1-t)²P3 + 5t⁴(1-t)P4 + t⁵P5  with t in [0,1]
 *       = t⁵ [   -1 P0   +5 P1  -10 P2  +10 P3   -5 P4   +1 P5  ]
 *       + t⁴ [   +5 P0  -20 P1  +30 P2  -20 P3   +5 P4  ]
 *       + t³ [  -10 P0  +30 P1  -30 P2  +10 P3  ]
 *       + t² [  +10 P0  -20 P1  +10 P2  ]
 *       + t¹ [   -5 P0   +5 P1  ]
 *       + t⁰ [   +1 P0  ]
 *
 *  And its derivatives
 *   B(t) =
 *             P0   P1   P2   P3   P4   P5
 *      t^5    -1    5  -10   10   -5    1
 *      t^4     5  -20   30  -20    5    0
 *      t^3   -10   30  -30   10    0    0
 *      t^2    10  -20   10    0    0    0
 *      t^1    -5    5    0    0    0    0
 *      t^0     1    0    0    0    0    0
 *
 *  B’(t) =
 *             P0   P1   P2   P3   P4   P5
 *      t^4    -5   25  -50   50  -25    5
 *      t^3    20  -80  120  -80   20    0
 *      t^2   -30   90  -90   30    0    0
 *      t^1    20  -40   20    0    0    0
 *      t^0    -5    5    0    0    0    0
 *
 *  B’’(t) =
 *             P0   P1   P2   P3   P4   P5
 *      t^3   -20  100 -200  200  -100  20
 *      t^2    60 -240  360 -240   60    0
 *      t^1   -60  180 -180   60    0    0
 *      t^0    20  -40   20    0    0    0
 *
 * It's now straightforward to see that  - position(0) imposes P0      - position(1) imposes P5
 *                                       - speed(0) imposes P1         - speed(1) imposes P4
 *                                       - acceleration(0) imposes P2  - acceleration(1) imposes P3
 *
 * Once we have P0-5, we can evaluate B'(t) on some (~10000) points to get the average speed between P0 and P5
 *
 * We still need to answer the question on how to choose the points between which we build the Bezier curve.
 * For passing all test-cases (even evil.in), it's sufficient to split the [0,1] time interval into 32 equally long stages.
 * But a better approach is to choose the segment for which the last upgrade (1 more point added) changed most its influence
 * on the average speed (i.e. average speed on segment * duration of segment). Once this segment is identified, split it into
 * two equally long sub-segments.
 *
 * Last but not least, care has to be taken when scaling the Bezier curves (time does not go always from [0,1] but might go from [0.25,0.375] e.g.
 *
 * Quadrature is the shorter to code but less precise alternative.
 */

#include "boomerang.h"
#include <cmath>
#include <list>
using namespace std;

struct TPoint
{
	double x, y;
};

class TStage
{
    public: 
	double t0, t5;
	TPoint P0, P1, P2, P3, P4, P5;
	double avs;
	double error;
	
	public:
	void ask_bezierPoints();
	double get_avs(double t0, double t1);
	
	public:
	TStage(double t0, double t1) : t0(t0), t5(t1)
	{
		ask_bezierPoints();
		avs = get_avs(0,t5-t0);
	}
};

void TStage::ask_bezierPoints()
{
	P0.x = positionx(t0);
	P0.y = positiony(t0);
	P1.x = speedx(t0)/5*(t5-t0) + P0.x;
	P1.y = speedy(t0)/5*(t5-t0) + P0.y;
	P2.x = accelerationx(t0)/20*(t5-t0)*(t5-t0) + 2*P1.x - P0.x;
	P2.y = accelerationy(t0)/20*(t5-t0)*(t5-t0) + 2*P1.y - P0.y;
	
	P5.x = positionx(t5);
	P5.y = positiony(t5);
	P4.x = -speedx(t5)/5*(t5-t0) + P5.x;
	P4.y = -speedy(t5)/5*(t5-t0) + P5.y;
	P3.x = accelerationx(t5)/20*(t5-t0)*(t5-t0) + 2*P4.x - P5.x;
	P3.y = accelerationy(t5)/20*(t5-t0)*(t5-t0) + 2*P4.y - P5.y;
}

double TStage::get_avs(double ta, double tb)
{
	double vx, vy, t, mean(0);
	double vx4 = -5*P0.x + 25*P1.x - 50*P2.x + 50*P3.x -25*P4.x +5*P5.x;
	double vy4 = -5*P0.y + 25*P1.y - 50*P2.y + 50*P3.y -25*P4.y +5*P5.y;
	double vx3 = 20*P0.x - 80*P1.x + 120*P2.x - 80*P3.x + 20*P4.x;
	double vy3 = 20*P0.y - 80*P1.y + 120*P2.y - 80*P3.y + 20*P4.y;
	double vx2 = -30*P0.x + 90*P1.x - 90*P2.x + 30*P3.x;
	double vy2 = -30*P0.y + 90*P1.y - 90*P2.y + 30*P3.y;
	double vx1 = 20*P0.x - 40*P1.x + 20*P2.x;
	double vy1 = 20*P0.y - 40*P1.y + 20*P2.y;
	double vx0 = -5*P0.x + 5*P1.x;
	double vy0 = -5*P0.y + 5*P1.y;
	double totPoints(10000);
	int a(ta/(t5-t0)*totPoints), b(tb/(t5-t0)*totPoints);
	
	for (int i=a; i<=b; i++)
	{
		 t = i/totPoints;
		 vx = ((((vx4*t+vx3)*t+vx2)*t+vx1)*t+vx0)/(t5-t0);
		 vy = ((((vy4*t+vy3)*t+vy2)*t+vy1)*t+vy0)/(t5-t0);
		 mean += sqrt(vx*vx+vy*vy)/(b-a+1);
	}
	return mean;
}
	
int main(int argc, char** argv)
{	
	list<TStage> stages;
	while(1)
	{
		// reset
		stages.clear();
		stages.push_back(TStage(0.0,1.0));
		stages.front().error=0;
		
		// ask as many questions as possible
		while (queries_left()>0)
		{
			double maxError(-1);
			
			// find worst stage
			list<TStage>::iterator stage, worstStage;
			for (stage = stages.begin(); stage != stages.end(); ++stage)
				if (stage->error > maxError)
				{
					worstStage = stage;
					maxError = worstStage->error;
				}
			
			// split worst stage
			double deltaT = worstStage->t5-worstStage->t0;
			stages.push_back(TStage(worstStage->t0,worstStage->t0+deltaT/2));
			stages.back().error = abs(stages.back().avs - worstStage->get_avs(0.0,deltaT/2)) * (stages.back().t5-stages.back().t0);
			stages.push_back(TStage(worstStage->t0+deltaT/2,worstStage->t5));
			stages.back().error = abs(stages.back().avs - worstStage->get_avs(deltaT/2,deltaT)) * (stages.back().t5-stages.back().t0);
			stages.erase(worstStage);
		}
		
		// compute average speed
		double avs(0.0);
		for (list<TStage>::iterator stage = stages.begin(); stage != stages.end(); ++stage)
			avs += stage->avs * (stage->t5-stage->t0);
		answer(avs);
	}

	return 0;
}