#include "terra.h"
#include <vector>
#include <iostream>
#include <bitset>
#include <cassert>
#include <map>

using namespace std;
typedef bitset<50> bs;
int C, P, cityDesc[50][8];

bs maskyes[8][4];
bs maskno[8][4];


class comparebs
{
	public:
		bool operator()(const bs a, const bs b)
		{
			for(int i=0;i<C;++i)
			{
				//Stupid bitset doesn't have a proper comparison function
				if(a[i]==b[i])
					continue;	
				return a[i]<b[i];
			}
			return false;
		}
};

map<bs, int, comparebs> cache;

int abs(int a)
{
	if(a<0)
		return -a;
	return a;
}
void prepare_masks()
{
	for(int pp = 0;pp<P;++pp)
		for(int vv=1;vv<=3;++vv)
		{
			for(int i=0;i<C;++i)
			{
				if((cityDesc[i][pp] == vv))
					maskno[pp][vv][i] = 1;
				else
					maskyes[pp][vv][i] = 1;
			}
		}

}

int find_best_simple(bs a)
{
	static int k=-1;k++;
	return (k%P) + (k/P)*64;
}
int find_best_greedy(bs a)
{
	int bestscore=C;
	int bestmove=0;
	for(int pp = 0;pp<P;++pp)
		for(int vv=1;vv<=3;++vv)
		{
			int yesscore = (a|maskyes[pp][vv]).count();
			int noscore = (a|maskno[pp][vv]).count();

			if(abs(yesscore-noscore)<=bestscore)
			{
				bestscore = abs(yesscore-noscore);
				bestmove = pp + vv*64;
			}
		}
	cerr<<"Greedy"<<endl;
	return bestmove;
}
int minmax(bs a, int & bestmove, bool nocache)
{
	if(a.count() == (unsigned) C-1)
	{
		bestmove=-1;
		return 0;
	}

	if(!nocache)
	{
		map<bs, int>::iterator iter = cache.find(a);
		if(iter!=cache.end())
		{
			return iter->second;
		}
	}

	int bestcost = C;
	for(int pp = 0;pp<P;++pp)
		for(int vv=1;vv<=3;++vv)
		{
			int nowscore = a.count();
			bs yesbs = a|maskyes[pp][vv];
			bs nobs = a|maskno[pp][vv];
			int yesscore = yesbs.count();
			int noscore = nobs.count();

			//Not interesting if we don't make progress
			if(nowscore == yesscore || nowscore == noscore)
				continue;

			//Get expected moves of both solutions
			int dummy;
			int yescost = minmax(yesbs, dummy, false);
			int nocost = minmax(nobs, dummy, false);

			int realcost = max(yescost, nocost)+1;

			if(realcost < bestcost)
			{
				bestcost = realcost;
				bestmove = pp + vv*64;
			}
		}
	cache[a]=bestcost;
	return bestcost;
}

int find_best(bs a)
{
	//Minmax
	int bestmove;
	int cost = minmax(a, bestmove, true);
	//cerr<<"Computed cost: "<<cost<<endl;

	if(bestmove==-1)
		return find_best_greedy(a);
	return bestmove;

}

bs apply_move(bs a, int move)
{
	int pp = move%64;
	int vv = move/64;

	bool ans = heidi_askQuestion(pp+1, vv);

	if(ans)
		a|=maskyes[pp][vv];
	else
		a|=maskno[pp][vv];

	return a;
}
int main(int argc, char** argv)
{

	C = number_cities();
	P = number_properties();
	read_catalog(cityDesc);
	prepare_masks();

	bs a;

	assert((signed)a.count()==0);
	while((signed)a.count() < C-1)
	{
		int bestmove = find_best(a);
		a = apply_move(a, bestmove);
	}

	assert((signed)a.count()==C-1);

	for(int i=0;i<C;++i)
		if(a[i]==0)
		{
			heidi_tellCity(i+1);
			return 0;
		}

	return 1;
}
