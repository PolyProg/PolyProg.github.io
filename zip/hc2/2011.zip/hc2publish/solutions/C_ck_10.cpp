/* 
 * Solution by Christian Kauth - 09/12/2010 - 100%
 * -----------------------------------------------
 *
 * - Solution for 100% score : O(N log(N))
 *   This is a 2-Sat problem that can be solved with any linear-time algorithm for strongly connected components and binary search.
 *   The question on whether there is a solution to a tour with n sights, can be expressed as an implication graph. For each pair of
 *   consecutive sights, there are 2 possible routes. Each road may have two states, up/down or east/west. Hence if one of the 2 possible
 *   routes is in contradiction with other routes, then it implies that the alternative routes obeys the constraints imposed by this pair.
 *   Once the implication graph is built (O(N)), Tarjan's algorithm is used to find strongly connected components (O(N)) and it must be
 *   checked whether no strongly connected component holds a contradiction (O(N)) (e.g. one and the same avenue has to go up and down).
 *   Hence the answer to the above question can be computed in O(N). And the maximum value of sights that can be visited can then be found
 *   via binary search, leading to a overall complexity of O(N log(N)).
 *
 * - Solution for 70% score : O(N^2) to O(N^2 log(N))
 *   Solving the 2-Sat problem with a O(N^2) algorithm for strongly connected components leads to a O(N^2 log(N)) solution, while a linear
 *   time solution for strongly connected components in conjunction with linear search leads to O(N^2). Both algorithms score 70%
 *
 * - Solution for 40% score : O(2^(A+S))
 *   Brute force backtracking by trying every combination of orientations of the roads scores 40%
 */

#include "stdio.h"
#include <vector>
using namespace std;

#define MAXS 1000			// maximum number of avenues
#define MAXA 1000			// maximum number of streets
#define UP 0				// avenue direction is up (north)
#define DN 1				// avenue direction is down (south)
#define LT 0				// street direction is left (west)
#define RT 1				// street direction is right (east)
#define UNDEF -1			// road direction is not yet defined

struct TSight
{
	int a, s;
};

int A;										// the number of avenues
int S;										// number of streets
int N;										// number of sights on Heidi's list
TSight sights[MAXS*MAXA];					// the sights of Heidi's list
vector<int> ig[(MAXS+MAXA)<<1];				// the implication graph for the 2-Sat problem
int myStack[(MAXS+MAXA)<<1];				// the stack for Tarjan's strongly connected component algorithm
int sCnt;									// counts the elements on the stack
int sccIndex[(MAXS+MAXA)<<1];				// marker for Tarjan's algorithm
int sccLowLink[(MAXS+MAXA)<<1];				// marker for Tarjan's algorithm
bool isOnStack[(MAXS+MAXA)<<1];				// marker for Tarjan's algorithm
int globInd;								// marker for Tarjan's algorithm

bool read_case();							// reads the test-case
void build_implicationGraph(int n);			// builds the implication graph for the 2-sat problem with the n first sights
bool contradiction_check(int v);			// check for contradiction in strongly connected component rooted at v
bool tarjan(int v);							// finds strongly connected components reachable from v
bool two_sat(int n);						// tells whether the sight-seeing tour on n sights has a solution
int binary_search();						// performs binary search on the maximum number of sights that can be in the tour

bool read_case()
{
	int a,s;
	scanf("%d %d %d",&A,&S,&N);

	if (A==0 && S==0 && N==0)
		return false;

	for (int i=0; i<N; i++)
	{
		scanf("%d %d",&a,&s);
		sights[i].a = (a-1)<<1;
		sights[i].s = (A+s-1)<<1;
	}

	return true;
}


void build_implicationGraph(int n)
{
	int a1, s1, a2, s2;

	// clear implication graph
	for (int i=0; i<(A+S)<<1; i++)
		ig[i].clear();

	// add edges to implication graph
	for (int i=0; i<n-1; i++)
	{
		a1 = sights[i].a;
		s1 = sights[i].s;
		a2 = sights[i+1].a;
		s2 = sights[i+1].s;
		
		if (s1==s2)	{						// route is horizontal ...
			if (a2>a1)											// ... route goes right
				ig[s1+LT].push_back(s1+RT);
			else if (a2<a1)										// ... route goes left
				ig[s1+RT].push_back(s1+LT);
		}
		else if (a1==a2) {					// route is vertical ...
			if (s2>s1)											// ... route goes up
				ig[a1+DN].push_back(a1+UP);
			else if (s2<s1)										// ... route goes down
				ig[a1+UP].push_back(a1+DN);
		}
		else if (a2>a1 && s2>s1) {			// route goes up-right
			ig[s1+LT].push_back(s2+RT);	ig[s1+LT].push_back(a1+UP);
			ig[s2+LT].push_back(s1+RT); ig[s2+LT].push_back(a2+UP);
			ig[a1+DN].push_back(s1+RT);	ig[a1+DN].push_back(a2+UP);
			ig[a2+DN].push_back(s2+RT);	ig[a2+DN].push_back(a1+UP);
		}
		else if (a2<a1 && s2>s1) {			// route goes up-left
			ig[s1+RT].push_back(s2+LT);	ig[s1+RT].push_back(a1+UP);
			ig[s2+RT].push_back(s1+LT); ig[s2+RT].push_back(a2+UP);
			ig[a1+DN].push_back(s1+LT);	ig[a1+DN].push_back(a2+UP);
			ig[a2+DN].push_back(s2+LT);	ig[a2+DN].push_back(a1+UP);
		}
		else if (a2>a1 && s2<s1) {			// route goes down-right
			ig[s1+LT].push_back(s2+RT);	ig[s1+LT].push_back(a1+DN);
			ig[s2+LT].push_back(s1+RT); ig[s2+LT].push_back(a2+DN);
			ig[a1+UP].push_back(s1+RT);	ig[a1+UP].push_back(a2+DN);
			ig[a2+UP].push_back(s2+RT);	ig[a2+UP].push_back(a1+DN);
		}
		else if (a2<a1 && s2<s1) {			// route goes down-left
			ig[s1+RT].push_back(s2+LT);	ig[s1+RT].push_back(a1+DN);
			ig[s2+RT].push_back(s1+LT); ig[s2+RT].push_back(a2+DN);
			ig[a1+UP].push_back(s1+LT);	ig[a1+UP].push_back(a2+DN);
			ig[a2+UP].push_back(s2+LT);	ig[a2+UP].push_back(a1+DN);
		}
	}
}


bool contradiction_check(int v)
{
	int vv;
	vector<int> inComponent(S+A,UNDEF);
	do
	{
		vv = myStack[--sCnt];
		isOnStack[vv]=false;
		if (inComponent[vv>>1]!=UNDEF)
		{
			if (inComponent[vv>>1] != (vv&1))
				return false;	
		}
		else
			inComponent[vv>>1] = vv&1;
	} while (vv!=v);
	return true;
}


bool tarjan(int v)
{
	int vv;

	sccIndex[v] = globInd;
	sccLowLink[v] = globInd;
	globInd++;
	myStack[sCnt++]=v;
	isOnStack[v]=true;

	for (unsigned int i=0; i<ig[v].size(); i++)
	{
		vv = ig[v][i];
		if (sccIndex[vv]==UNDEF)
		{
			if (!tarjan(vv))
				return false;
			sccLowLink[v] = min(sccLowLink[v],sccLowLink[vv]);
		}
		else if (isOnStack[vv])
			sccLowLink[v] = min(sccLowLink[v],sccIndex[vv]);
	}

	// if strongly connected component is found, check for contradictions
	return (sccLowLink[v]!=sccIndex[v]) || contradiction_check(v);
}


bool two_sat(int n)
{
	// initialize
	globInd=0;
	sCnt=0;
	for (int i=0; i<(A+S)<<1; i++)
	{
		sccIndex[i]=UNDEF;
		isOnStack[i]=false;
	}
	build_implicationGraph(n);

	// check for contradiction in strongly connected components of implication graph
	for (int i=0; i<(A+S)<<1; i++)
		if (sccIndex[i]==UNDEF && !tarjan(i))
			return false;
	return true;
}


int binary_search()
{
	int l(1),r(N+1),x;

	while(l!=r)
	{
		x = (l+r)/2;
		two_sat(x) ? l=x+1 : r=x;
	}
	return l-1;
}


int main() 
{
	while (read_case())
		printf("%i\n",binary_search());
	return 0;
}



