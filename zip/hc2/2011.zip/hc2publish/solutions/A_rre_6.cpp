#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cassert>
#include <climits>
#include <cmath>

using namespace std;

typedef int D;

typedef vector<D> VD;
typedef vector<VD> VVD;
typedef vector<VVD> VVVD;

VVVD* secp;
size_t n;

const D SENTINEL=-2;
const D ONE = (1L<<(sizeof(D)*8-9)); // INT_MAX/256

/*
int binary_entropy(int n)
{
	const int OEIS_A003314[] = {0,2,5,8,12,16,20,24,29,34,39,44,49,54,59,64,70,
 76,82,88,94,100,106,112,118,124,130,136,142,148,
 154,160,167,174,181,188,195,202,209,216,223,230,
 237,244,251,258,265,272,279,286,293,300,307,314,
 321,328,335};

	return OEIS_A003314[n-1];
}
*/
double solve(VD & p)
{
	VVVD sec(p.size(), VVD(p.size(), VD((p.size()*(p.size()+1))/2, SENTINEL)));
	secp = &sec;
	n=p.size();
	// sec is:  FROM TO COST = security

	for(size_t i=0;i<sec.size();++i)
	{
		sec[i][i][0]=p[i];
		//printf("Optimal cost for %d %d (c=%d) is %f\n", (int)i, (int)i, 1, (p[i]+0.)/ONE);
	}

	for(size_t c = 0; c<sec[0][0].size();++c)
	{
		for(size_t L=0;L<n;++L)
		{
			for(size_t i=0;i<n-L;++i)
			{
				size_t j=i+L;
				size_t mergecost = j-i+1;
				if(c < mergecost) //not enough money
					continue;
				size_t available = c - mergecost;

				D optimal=SENTINEL;
				int bestk=-1, bestd=-1;
				for(size_t k=i;k<j;++k)
				{
					for(size_t d=0;d<=available;++d)
					{
						D sec1 = sec[i][k][d];
						if(sec1 == SENTINEL)
							continue;
						D sec2 = sec[k+1][j][available-d];
						if(sec2 == SENTINEL)
							continue;

						D cc = (sec1 + sec2)/2;
						if(cc>optimal)
						{
							optimal=cc;
							bestk = k;
							bestd = d;
						}
					}

				}
				sec[i][j][c] = optimal;
			}
		}
	}

	int minc=0;
	D maxsec=SENTINEL;
	for(size_t c = 0; c<sec[0][0].size();++c)
	{
		if(!minc && sec[0][n-1][c] != SENTINEL)
			minc = c;
		if(sec[0][n-1][c] > maxsec)
			maxsec=sec[0][n-1][c];
		//fprintf(stderr, "Security at %d is %f\n", (int)c, (sec[0][n-1][c]+0.)/ONE);
	}
	//fprintf(stderr, "Min cost is %d (%d)\n", minc, binary_entropy(n));
	//printf("Max security it %f\n", maxsec);
	double besteff=0;
	for(size_t c = 0; c<sec[0][0].size();++c)
	{
		double secc = sec[0][n-1][c];
		if(secc != SENTINEL)
		{
			double eff = (((secc+0.)/maxsec) * minc)/c;
			//printf("At cost=%d security is %f, eff=%f\n", (int)c, (secc+0.)/ONE, eff);
			if(eff>besteff)
				besteff=eff;
		}
	}

	return besteff;


}

int main(int argc, char** argv)
{
	while(1)
	{
		int n;
		VD p;

		cin>>n;
		assert(!cin.fail());
		if(n==0)
			return 0;
		for(int i=0;i<n;++i)
		{
			D k;
			cin>>k;
			assert(!cin.fail());
			k*=ONE;
			p.push_back(k);
		}

		sort(p.begin(), p.end());

		double res = solve(p);
		printf("%.6f\n", res);
		///fprintf(stderr, "%.6f\n", res);
	}

}

