#include "boomerang.h"
#include "math.h"

double f(double t)
{
	return sqrt( speedx(t)*speedx(t) + speedy(t)*speedy(t) );
}
//Rectangle rule
int main(int argc, char** argv)
{
	const double totaltime = 1;
	while(1)
	{
		int maxqueries = queries_left();
		double distance=0;
		int i;
		for(i=0;i<maxqueries;++i)
		{
			double ti = i/(maxqueries+0.);
			double tnext = (i+1)/(maxqueries+0.);
			distance+= (tnext-ti) * f((ti+tnext)/2.);
		}

		answer(distance/totaltime);
	}

	return 0; /*We will never get here*/
}
