/* 
 * Furniture - Solution by Christian Kauth - 27/01/2011
 * ----------------------------------------------------
 *
 * The backbone of the algorithm solving this problem is a breadth-first-search. The art lies in the way of encoding the states!
 *
 * One way to represent the room is to associate to each piece its offset (in 2D) with respect to its initial position.
 * Hence the following time complexities result : (room of size NxM, number of pieces P)
 * - check whether move is legal : O(NMP)
 * - perform move                : O(1)
 * - check whether room is final : O(NM)
 *
 * All these offsets define the state, and the state-space is huge! Hence we use hashing to store and retrieve the constellation
 * in constant time!
 *
 * Although hashing is faster than a map, you still need to code it correctly! I probably didn't, as it scores 9 out of 10 with
 * one runtime error. Nobody's perfect, right? ;) I leave it to you as an exercise to find the bug. Don't hesitate to inform me if
 * you find it! :) Don't worry, Robert's solution uses maps and doesn't crash.
 */

#include<stdio.h>
#include<vector>
#include<queue>
#include<string>

using namespace std;

#define MAXP 26			// maximum number of pieces
#define MAXN 20			// maximum size of appartment
#define MAXD 4			// number of directions
#define MAXH 100003		// prime size of the hash-table
#define INF 1000000		// a finite value for infinity
#define X 0
#define Y 1

struct TPiece
{
	int dx[2];										// overall 2D-offset of piece compared to initial position
};

struct TConstellation
{
	TPiece pieces[MAXP];							// description of each piece
	int nMoves;										// number of moves needed to get into this constellation
	char lastP;										// last piece moved
	int dir;										// last direction of motion
	int dad;										// dad constellation
	void copy_pieces_from(TPiece p[]);				// copies pieces' location from p
	bool other_pieces_than(TPiece p[]);				// compares pieces' location with p
};

const int dir[4][2] = {{-1,0},{0,-1},{1,0},{0,1}};	// possible directions of motion
const char dirSymbol[4] = {'^','<','v','>'};		// symbols for the directions of motion

int N, M, E, P;										// appartment dimensions, Heidi's energy and number of pieces
int roomIn[MAXN][MAXN], roomOut[MAXN][MAXN];		// initial and final room descriptions
TConstellation iniConst;							// starting constellation
TConstellation hashTable[MAXH];						// a hash-table to store the visited constellations and the number of moves to get there

/* copies pieces' location */
void TConstellation::copy_pieces_from(TPiece p[])
{
	for (int i=0; i<P; i++)
		pieces[i] = p[i];
}

/* compares pieces' location */
bool TConstellation::other_pieces_than(TPiece p[])
{
	for (int i=0; i<P; i++)
		if (pieces[i].dx[X]!=p[i].dx[X] || pieces[i].dx[Y]!=p[i].dx[Y])
			return true;
	return false;
}
	
/* reads the input */
bool read_case() 
{
	char pos;
	P=0;
	scanf("%d %d %d\n",&N,&M,&E);
	if ((N|M|E) == 0)
		return false;
		
	// read initial room
	for (int i=0; i<N; i++) {
		for (int j=0; j<M; j++) {
			scanf("%c",&pos);
			roomIn[i][j] = pos-'a';
			P = max(P,roomIn[i][j]+1);
		}
		scanf("\n");
	}
	
	// read final room
	for (int i=0; i<N; i++) {
		for (int j=0; j<M; j++) {
			scanf("%c",&pos);
			roomOut[i][j] = pos-'a';
		}
		scanf("\n");
	}
	
	// reset hashtable
	for (int i=0; i<MAXH; i++)
		hashTable[i].nMoves = INF;
	return true;		
}

/* primary hash function */
int h1(TPiece p[])
{
	int h = (p[0].dx[X]+MAXN)*(MAXN>>1)+p[0].dx[Y]+MAXN;
	for (int i=1; i<P; i++)
		h = ((h*(MAXN>>1)+p[i].dx[X]+MAXN)*(MAXN>>1)+p[i].dx[Y]+MAXN) % MAXH;
	return h;	
}

/* secondary hash function */
int h2(TPiece p[])
{
	return (MAXN>>1) - (p[0].dx[X]+MAXN-1);
}

/* insert a given constellation into hashtable */
int hash_insert(TConstellation c, int pos, int dad, int lastP, int dir)
{
	hashTable[pos].copy_pieces_from(c.pieces);
	hashTable[pos].nMoves = c.nMoves;
	hashTable[pos].dad = dad;
	hashTable[pos].lastP = lastP;
	hashTable[pos].dir = dir;
	return pos;	
}

/* returns (potential) position of constellation in hashtable */
int hash_check(TConstellation c)
{
	int x = h1(c.pieces);
	int u = h2(c.pieces);
	while (hashTable[x].nMoves!=INF && hashTable[x].other_pieces_than(c.pieces))
		x = (x+u)%MAXH;
	return x;
}

/* checks whether the suggested move is legal in the current constellation */
bool legal_move(TConstellation c, int p, int d)
{
	int dRow = c.pieces[p].dx[X]+dir[d][X];
	int dCol = c.pieces[p].dx[Y]+dir[d][Y];
	for (int i=0; i<N; i++)
		for (int j=0; j<M; j++)
			if (i-dRow>=0 && i-dRow<N && j-dCol>=0 && j-dCol<M && roomIn[i-dRow][j-dCol]==p)
			{
				// check for crash with wall
				if (roomIn[i][j]=='#'-'a')
					return false;
					
				// check for crash with other piece
				for (int k=0; k<P; k++)
					if (k!=p) {
						int kRow = c.pieces[k].dx[X];
						int kCol = c.pieces[k].dx[Y];
						if (i-kRow>=0 && i-kRow<N && j-kCol>=0 && j-kCol<M && roomIn[i-kRow][j-kCol]==k)
							return false;
					}
			}
	return true;
}

/* checks whether the constellation can be considered final */
bool isFinal(TConstellation c)
{
	int row, col;
	for (int i=1; i<N-1; i++)
		for (int j=1; j<M-1; j++)
			if (roomOut[i][j]!='#'-'a')
			{
				// check whether labeled pieces arrived
				if (roomOut[i][j]!='.'-'a' && roomOut[i][j]!='?'-'a')
				{
					row = i-c.pieces[roomOut[i][j]].dx[X];
					col = j-c.pieces[roomOut[i][j]].dx[Y];
					if (row<0 || row>=N || col<0 || col>=M || roomIn[row][col]!=roomOut[i][j])
						return false;			
				}
					
				// check whether no piece blocks passage
				if (roomIn[i][j]!='.'-'a')
				{
					row = i+c.pieces[roomIn[i][j]].dx[X];
					col = j+c.pieces[roomIn[i][j]].dx[Y];
					if (row>=0 && row<N && col>=0 && col<M && roomOut[row][col]=='.'-'a')
						return false;
				}					
			}
	return true;
}

/* writes the move sequence to transform the initial room into the final room */
void output(int pos)
{
	TConstellation c(hashTable[pos]);
	string seq("");

	while(c.nMoves>0) {
		seq += dirSymbol[c.dir];
		seq += c.lastP+'a';
		c = hashTable[c.dad];
	}

	for (int i=seq.size()-1; i>=0; i--)
		printf("%c",seq[i]);
	printf("\n");	
}

/* performs a bfs to determine the shortest sequence of moves to reach the final constellation */
bool fastest_rearrange()
{
	queue<int> q;
	TConstellation next;
	int currentPos, nextPos;
	
	q.push(hash_insert(iniConst,hash_check(iniConst),-1,-1,-1));
	
	while (!q.empty()) {
		currentPos = q.front();
		next.copy_pieces_from(hashTable[currentPos].pieces);
		next.nMoves = hashTable[currentPos].nMoves+1;
		q.pop();

		// check whether energy is used
		if (next.nMoves>E+1)
			break;
		
		// check whether room is ready
		if (isFinal(next)) {
			output(currentPos);
			return true;
		}
		
		// try every possible move
		for (int i=0; i<P; i++)
			for (int d=0; d<4; d++) {
				if (legal_move(next,i,d)) {
					next.pieces[i].dx[X] += dir[d][X];
					next.pieces[i].dx[Y] += dir[d][Y];
					nextPos=hash_check(next);
					if (hashTable[nextPos].nMoves==INF)
						q.push(hash_insert(next,nextPos,currentPos,i,d));
					next.pieces[i].dx[X] -= dir[d][X];
					next.pieces[i].dx[Y] -= dir[d][Y];
				}
			}
	}
	return false;
}

int main()
{
	while (read_case())
	{
		if (!fastest_rearrange())
			printf("Impossible\n");
	}
	return 0;
}
