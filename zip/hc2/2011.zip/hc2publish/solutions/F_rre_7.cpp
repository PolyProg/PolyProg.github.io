#include "boomerang.h"
#include "math.h"

double f(double t)
{
	return sqrt( speedx(t)*speedx(t) + speedy(t)*speedy(t) );
}
//Simpson rule
int main(int argc, char** argv)
{
	const double totaltime = 1;
	while(1)
	{
		int maxqueries = queries_left();
		int qq = (maxqueries-1)/2;
		double distance=0;
		int i;
		for(i=0;i<qq;++i)
		{
			double ti = i/(qq+0.);
			double tnext = (i+1)/(qq+0.);
			distance+= (tnext-ti)/6 * ( f(ti) + 4*f((ti+tnext)/2.) + f(tnext));
		}

		answer(distance/totaltime);
	}

	return 0; /*We will never get here*/
}
