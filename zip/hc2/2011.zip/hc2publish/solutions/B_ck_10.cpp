/*
 * Terra Incognita - Solution by Christian Kauth - 30/01/2011
 * ----------------------------------------------------------
 * 
 * This problem was designed such that it is quite easy to score 70% and quite hard to score 100% :)
 * 
 * Brute force :  (40% solution) Ask 2 questions about each property to determine its value (or just 1) 
 *                and stop as soon as one only city complies with the property values.
 *
 * Greedy      :  (70% solution) At each turn, ask the question that garantees under a worst case answer a
 *                minimum number of cities remaining, i.e. splits the cities most evenly
 *
 * MinMax      :  (100% solution) Rather than taking the states as the sets of remaining possible cities
 *                (there are 2^50 of them), one should choose the sets of remaining possible property values.
 *                In fact, each property can take only 3 values, so there are 2^3-1 possible values for each
 *                1-property-state. With 8 properties in total, this sums to less than 2^24 states. One can 
 *                now run a minmax through this statespace and use memorization! The initial state is 1<<(P*3)-1
 *                (all properties can have all values) and the final state will have exactly P bits set. It is 
 *                essential to use bitsets (rather than arrays of boolean) and efficient bit counting to remain 
 *                in the time limits!
 */

#include <stdio.h>
#include <algorithm>
#include "terra.h"
using namespace std;

#define MAXV 3						// maximum number of values per property
#define MAXP 8						// maximum number of properties
#define MAXC 50						// maximum number of cities
#define INFQ 120					// infinite number of questions
#define NSTATES (1<<(MAXP*MAXV))	// maximum number of states

int C;										// number of cities
int P;										// number of properties
int cities[MAXC];							// description of the cities
char minQ[NSTATES];							// minimum number of questions from a given state till answer
char bestQ[NSTATES];						// cleverest question to ask at a given state

/* asks for Heidi's travel book */
void read_case()
{
	int cityDesc[MAXC][MAXP];
	
	// encode cities
	C = number_cities();
	P = number_properties();
	read_catalog(cityDesc);
	for (int c=0; c<C; c++)
	{
		cities[c]=0;
		for (int p=0; p<P; p++)
			cities[c] |= 1<<(p*MAXV+cityDesc[c][p]-1);
	}
	
	// reset the minimal number of questions
	for (int i=0; i<(1<<(P*MAXV)); i++)
		minQ[i] = INFQ;
}

/* counts the number of bits set in 'n' */
int bit_count (int n)
{
	static int bcnt4[16] = {0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 2, 3, 2, 3, 3, 4};
	int nBits(0);
	while (n)
	{
		nBits += bcnt4[n & 0xF];
		n >>= 4;
	}
	return nBits;
}

/* counts the number of remaining candidate cities in state 'state' */
int city_count(int state)
{
	int nCities(0);
	for (int i=0; i<C; i++)
		nCities += bit_count(cities[i]&state)==P;
	return nCities;
}

/* finds the best question to ask in state 'cState' */
void find_clever_question(int cState)
{
	int tState, fState;
		
	// do we have a single candidate left?
	if (minQ[cState]==0 || city_count(cState)<=1)
	{
		minQ[cState] = 0;		
		return;
	}
	
	// try every answer to every value of every property
	for (char p=0; p<P; p++)
		if (((cState & (1<<(p*MAXV+0)))>0) + ((cState & (1<<(p*MAXV+1)))>0) + ((cState & (1<<(p*MAXV+2)))>0) > 1)
			for (char v=0; v<MAXV; v++)
				if (cState & (1<<(p*MAXV+v)))
				{
					// states after answer
					tState = cState & ~((1<<(p*MAXV+((v+1)%MAXV))) | (1<<(p*MAXV+((v+2)%MAXV))));
					fState = cState & ~(1<<(p*MAXV+v));
					
					// count remaining questions if answer is TRUE
					if (minQ[tState]==INFQ)
						find_clever_question(tState);
						
					// quit early if no better than the best so far
					if (minQ[tState]+1>=minQ[cState])
						continue;
		
					// count remaining questions if answer is FALSE
					if (minQ[fState]==INFQ)
						find_clever_question(fState);
				
					// check whether worst answer would still be best option
					if (minQ[fState]+1 < minQ[cState])
					{
						minQ[cState] = max(minQ[tState],minQ[fState])+1;
						bestQ[cState] = p*MAXV+v;
					}
				}
}

/* returns the index of the city Heidi's currently in */
int terra_cognita(int state)
{
	for (int i=0; i<C; i++)
		if (bit_count(state & cities[i])==P)
			return i;
	printf("no city matches\n");
	return -1;
}

/* emulates the phone conversation with Heidi */
void make_call()
{
	int state = (1<<(P*MAXV))-1;
	char p, v;
	int answer;

	do
	{		
		find_clever_question(state);
		p = bestQ[state]/MAXV;
		v = bestQ[state]%MAXV;
		answer = heidi_askQuestion(p+1,v+1);
		state = answer ? state & ~((1<<(p*MAXV+((v+1)%MAXV))) | (1<<(p*MAXV+((v+2)%MAXV)))) : state & ~(1<<(p*MAXV+v));
	} while (city_count(state)>1);

	heidi_tellCity(terra_cognita(state)+1);
}

int main()
{
	read_case();
	make_call();
	return 0;
}

// g++ solution100.cpp test_lib/terra.c -O2 -Wall
// ./a.out < io/test_01.in

