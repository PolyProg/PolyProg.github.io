#ifndef PREFIX_LIB_1_H_
#define PREFIX_LIB_1_H_

bool isValidPrefixSet(int n, char* prefix[]);

#endif //PREFIX_LIB_1_H_
