public class Sample {
  public int hello(void) {
    return 42;
  }
}

