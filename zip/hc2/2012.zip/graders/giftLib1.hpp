/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

// function you have to code
int find_heidi();

// grader function you may call
bool is_heidi_in(double year);
