#ifndef PREFIX_LIB_1_H_
#define PREFIX_LIB_1_H_

bool isFullPrefixSet(int n, char* prefix[]);

#endif //PREFIX_LIB_1_H_
