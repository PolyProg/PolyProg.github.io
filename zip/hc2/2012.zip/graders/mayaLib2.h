/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

// function you have to code
// R - number of rooms
// C[r] -- number of corridors in room r
int fetch_calendar(int R, int C[], int p[1024][16]);
