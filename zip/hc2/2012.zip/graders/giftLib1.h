/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

typedef int BOOL;
#define TRUE (!0)
#define FALSE (0)

// function you have to code
int find_heidi();

// grader function you may call
BOOL is_heidi_in(double year);
