/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

typedef int BOOL;

// function you have to code
int find_heidi();

// grader function you may call
BOOL is_heidi_in(double year);
