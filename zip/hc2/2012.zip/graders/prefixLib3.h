#ifndef PREFIX_LIB_3_H_
#define PREFIX_LIB_3_H_

int minimalNumberToMakeFull(int n, char* prefix[]);

#endif //PREFIX_LIB_3_H_
