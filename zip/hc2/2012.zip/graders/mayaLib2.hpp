/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

#include<vector>
using namespace std;

// function you have to code
int fetch_calendar(vector<vector<int> > p);
