/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

#include<string>
using namespace std;

// function you have to code
string ready_for_contest();

