/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

// function you have to code
void count_balloons(int N, int p[], int n[], int t[]);

// grader functions you may call
void min_balloons(int yourMinBound);
void max_balloons(int yourMaxBound);
