/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

// function you have to code
void find_medalists(int N, int p[], int n[], int t[]);

// grader functions you may call
void gold_medalist(int myGoldMedalist);
void silver_medalist(int mySilverMedalist);
void bronze_medalist(int myBronzeMedalist);
