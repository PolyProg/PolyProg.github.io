#ifndef PREFIX_LIB_1_H_
#define PREFIX_LIB_1_H_

typedef int BOOL;
#define FALSE (0)
#define TRUE (!0)

BOOL isValidPrefixSet(int n, char* prefix[]);

#endif //PREFIX_LIB_1_H_
