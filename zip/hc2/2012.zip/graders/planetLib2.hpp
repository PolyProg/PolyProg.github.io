#ifndef __PLANET_HPP
#define __PLANET_HPP

int countBorders(int nCities, double cityLat[], double cityLong[]);

#endif
