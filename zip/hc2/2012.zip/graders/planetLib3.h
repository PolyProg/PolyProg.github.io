#ifndef __PLANET_HPP
#define __PLANET_HPP

int countReachableCountries(int nCities, double cityLat[], double cityLong[]);

#endif
