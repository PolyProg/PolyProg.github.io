//#include "stdafx.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cstdlib>
#include <set>
#include <cstdio>
#include <cstring>
using namespace std;

#define MAX 1001

vector<int> minCover;	// the optimal solution
bool covered_row[MAX], covered_column[MAX];
bool presentationError(false);

const int RES_ACCEPTED=0;
const int RES_PRESENTATION=1;
const int RES_WRONG=2;
const int RES_RT_ERROR=7;
const int RES_RT_REEVAL=11;

int main(int argc, char** argv, char** envp)
{
	//Expected arguments:
	// 1. Real solution = minimum 
	// 2. Obtained solution
	// 3. Test case number (1-10)
	// 4. Input
	if(argc!=5)
	{
		cerr<<"Usage: "<<argv[0]<<
			" real_solution provided_solution testcase_no input"<<endl;
		cerr<<"Got "<<argc<<" args"<<endl;
		for(int i=0;i<argc;++i)
			cerr<<string(argv[i]).substr(0, 20)<<endl;
		return 1;
	}
	//int tc=atoi(argv[3]);

	fstream fsub(argv[2]);
	if(!fsub)
	{
		cerr<<"Couln't open submission file 1"<<endl;
		return RES_RT_ERROR;
	}
	fstream finput(argv[4]);
	if(!finput)
	{
		cerr<<"Couln't open input file 1"<<endl;
		return RES_RT_ERROR;
	}
	vector<int> minimum;
	fstream fmin(argv[1]);
	int ntc;
	if(!fmin)
	{
		//cout<<"Couln't open the first file"<<endl;
		//This corrects a BUG in Mooshak: the contents of the file and
		//not the file is passed as arguments
		stringstream ss;
		ss<<argv[1];
		ss>>ntc;
		if(ss.fail())
		{
			cerr<<"Couln't open solution file 1"<<endl;
			return RES_RT_ERROR;
		}
		for(int i=0;i<ntc;++i)
		{
			int m;
			ss>>m;
			if(ss.fail())
			{
				cerr<<"Couln't open solution file 2"<<endl;
				return RES_RT_ERROR;
			}
			minimum.push_back(m);
		}
	}
	else
	{
		fmin>>ntc;
		if(fmin.fail())
		{
			cerr<<"Couln't open solution file 3"<<endl;
			return RES_RT_ERROR;
		}
		for(int i=0;i<ntc;++i)
		{
			int m;
			fmin>>m;
			if(fmin.fail())
			{
				cerr<<"Couln't open solution file 4"<<endl;
				return RES_RT_ERROR;
			}
			minimum.push_back(m);
		}
	}

	for(int i=0;i<=ntc;++i)
	{
		string line;
		if(i!=0)
		{
			getline(fsub, line);
			if(line!="")
			{
				cerr<<"Case "<<i<<" nonenmpty line"<<endl;
				return RES_WRONG;
			}
		}
		int L, Z, N;
		finput>>L>>Z>>N;
		if(finput.fail())
		{
			cerr<<"Couln't open input file 2"<<endl;
			return RES_RT_ERROR;
		}
		if(N==0 && L==0 && Z==0 && i==ntc)
			return RES_ACCEPTED;
		else if(i==ntc)
		{
			cerr<<"Input too short"<<N<<L<<Z<<endl;
			return RES_WRONG;
		}
		int solmin;
		fsub>>solmin;
		if(fsub.fail())
		{
			cerr<<"Couln't open submission file 2"<<endl;
			return RES_RT_ERROR;
		}
		if(solmin>minimum[i] || solmin<0) //Accepts smaller minimums that ours in the off-chance that we are wrong :-)
		{
			cerr<<"Case "<<i<<" expected minimum: "<<minimum[i]<<" got "<<solmin<<endl;
			return RES_WRONG;
		}
		set<int> lau;
		set<int> zur;
		string lline, zline;
		getline(fsub, line);
		if(line!="")
		{
			cerr<<"Case "<<i<<" trash after minimum #"<<line<<"#"<<endl;
			return RES_WRONG;
		}
		getline(fsub, lline);
		getline(fsub, zline);
		stringstream lss, zss;
		lss<<lline;
		zss<<zline;
		char lc;
		lss>>lc;
		if(lc!='L')
		{
			cerr<<"Case "<<i<<" expected L"<<endl;
			return RES_WRONG;
		}
		zss>>lc;
		if(lc!='Z')
		{
			cerr<<"Case "<<i<<" expected Z"<<endl;
			return RES_WRONG;
		}
		while(!lss.fail())
		{
			int j;
			lss>>j;
			if(lss.fail())
				break;
			if(j<=0||j>L+1)
			{
				cerr<<"Case "<<i<<" unexpected number"<<j<<endl;
				return RES_WRONG;
			}
			lau.insert(j);
		}
		while(!zss.fail())
		{
			int j;
			zss>>j;
			if(zss.fail())
				break;
			if(j<=0||j>Z+1)
			{
				cerr<<"Case "<<i<<" unexpected number"<<j<<endl;
				return RES_WRONG;
			}
			zur.insert(j);
		}
		if(lau.size()+zur.size()!=(unsigned)solmin)
		{
			cerr<<"Case "<<i<<" Wrong number of candidates got "<<lau.size()+zur.size()<<" expected "<<solmin<<endl;
			return RES_WRONG;
		}

		//Read input
		for(int k=0;k<N;++k)
		{
			int l, z;
			finput>>l>>z;
			if(lau.find(l)==lau.end() && zur.find(z)==zur.end())
			{
				cerr<<"Case "<<i<<" Wrong number of candidates"<<endl;
				return RES_WRONG;
			}
		}

		if(solmin!=minimum[i])
		{
			cout<<"Solution size: "<<solmin<<" exp "<<minimum[i]<<endl;
			return RES_RT_REEVAL;
		}

		

	}

}
