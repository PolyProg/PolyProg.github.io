#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cstdlib>
#include <string>
#include <cmath>
using namespace std;

const int RES_ACCEPTED=0;
const int RES_PRESENTATION=1;
const int RES_WRONG=2;
const int RES_RT_ERROR=7;

const int MAX_ITEMS = 1000;

int main(int argc, char** argv, char** envp)
{

	//Expected arguments:
	// 1. Real solution
	// 2. Obtained solution
	// 3. Test case number (1-10)
	if(argc!=4)
	{
		cerr<<"Usage: "<<argv[0]<<
			" real_solution provided_solution testcase_no"<<endl;
		return 1;
	}
	int tc=atoi(argv[3]);

	vector<double> obtsol;
	//Read provided solution
	fstream ff(argv[2]);
	if(!ff)
	{
		cerr<<"Couln't open the obtained solution file"<<endl;
		return 1;
	}
	while(obtsol.size()<MAX_ITEMS)
	{
		double d;
		ff>>d;
		if(ff.fail())
		{
			break;
		}
		obtsol.push_back(d);
	}
	if(obtsol.size()<1)
	{
		cout<<"No solution provided"<<endl;
		return RES_WRONG;
	}

	//Read solution
	vector<double> realsol;
	fstream fin(argv[1]);
	if(!fin)
	{
		cout<<"Couln't open the first file"<<endl;
		//This corrects a BUG in Mooshak: the contents of the file and
		//not the file is passed as arguments
		stringstream ss;
		ss<<argv[1];
		while(realsol.size()<MAX_ITEMS)
		{
			double d;
			ss>>d;
			if(ss.fail())
			{
				break;
			}
			realsol.push_back(d);
		}
	}
	else
	{
		while(realsol.size()<MAX_ITEMS)
		{
			double d;
			fin>>d;
			if(fin.fail())
			{
				break;
			}
			realsol.push_back(d);
		}
	}
	if(realsol.size()<1)
	{
		cout<<"No real solution provided"<<endl;
		return RES_RT_ERROR;
	}
	if(realsol.size() != obtsol.size())
	{
		cout<<"Obtained solution too short/long: "<<
			obtsol.size()<<" should be "<<realsol.size()<<endl;
		return RES_WRONG;
	}
	double ABS_TOL = 1e-6;
	double REL_TOL = pow(10., -tc*1.-1);

	cout<<"TC: "<<tc<<" ABS_TOL: "<<ABS_TOL<<" REL_TOL: "<<REL_TOL<<endl;

	bool ok=true;
	double worst_error=0;
	for(int i=0;i<realsol.size();++i)
	{
		double obt = obtsol[i];
		double real = realsol[i];

		if(fabs(real-obt)>ABS_TOL)
		{
			if(fabs(real-obt)/real>worst_error)
				worst_error=fabs(real-obt)/real;
			if(fabs(real-obt)/real>REL_TOL)
			{
				cout<<"ITEM "<<i<<" obt: "<<obt<<" real: "<<real<<endl;
				cout<<" abs_error: "<<fabs(obt-real)<<
					" rel_error: "<<fabs(real-obt)/real<<endl;
				cout<<endl;
				ok=false;
			}
		}
	}
	if(ok)
	{
		cerr<<"OK TC: "<<tc<<" WORST ERROR: "<<worst_error<<endl;
		return RES_ACCEPTED;
	}
	cerr<<"NOT OK TC: "<<tc<<" WORST ERROR: "<<worst_error<<endl;
	return RES_WRONG;
}
