#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cstdlib>
#include <string>
using namespace std;

const int TOLERANCE=4; //percent
const int MAX_INPUT_SIZE=2500;

const int RES_ACCEPTED=0;
const int RES_PRESENTATION=1;
const int RES_WRONG=2;
const int RES_RT_ERROR=7;

int levenshtein(string source, string target)
{
	// Step 1
	const int n = source.length();
	const int m = target.length();
	if (n == 0)
		return m;
	if (m == 0)
		return n;
	vector<int> matrixi_1(m+1);
	vector<int> matrixi(m+1);

	// Initialize row & column
	matrixi[0] = 0;

	for (int j = 0; j <= m; j++)
	{
		matrixi[j] = j;
	}

	for (int i = 1; i <= n; i++)
	{
		matrixi_1 = matrixi;
		matrixi[0] = i;

		const char s_i = source[i - 1];

		for (int j = 1; j <= m; j++)
		{
			const char t_j = target[j - 1];

			int cost;
			if (s_i == t_j)
			{
				cost = 0;
			}
			else
			{
				cost = 1;
			}

			const int above = matrixi_1[j];
			const int left = matrixi[j - 1];
			const int diag = matrixi_1[j - 1];
			const int cell = min(above + 1, min(left + 1, diag + cost));

			matrixi[j] = cell;
		}
	}

	return matrixi[m];
}

int main(int argc, char** argv, char** envp)
{

	//Expected arguments:
	// 1. Real solution
	// 2. Obtained solution
	// 3. Test case number (1-10)
	if(argc!=4)
	{
		cerr<<"Usage: "<<argv[0]<<
			" real_solution provided_solution testcase_no"<<endl;
		cerr<<"Got "<<argc<<" args"<<endl;
		for(int i=0;i<argc;++i)
			cerr<<string(argv[i]).substr(0, 20)<<endl;
		return 1;
	}
	int tc=atoi(argv[3]);

	//Read provided solution
	fstream ff(argv[2]);
	if(!ff)
	{
		cerr<<"Couln't open the obtained solution file"<<endl;
		return 1;
	}
	string provsol;
	string provsoll;
	while(1)
	{
		string s, l;
		int ntc;
		ff>>ntc>>l;
		getline(ff, s);
		if(ff.fail())
		{
			cout<<"Input failed"<<endl;
			break;
		}
		if(ntc==tc)
		{
			provsol=s;
			provsoll=l;
			break;
		}
	}
	if(provsol.length()<1)
	{
		cout<<"No solution provided"<<endl;
		return RES_WRONG;
	}
	if(provsol.length()>MAX_INPUT_SIZE)
	{
		cout<<"Solution too long"<<endl;
		return RES_WRONG;
	}
	if(provsoll.length()!=1)
	{
		cout<<"Language wrong"<<endl;
		return RES_WRONG;
	}
	if(provsoll!="F" && provsoll!="D" && provsoll!="E")
	{
		cout<<"Unknown language"<<endl;
		return RES_WRONG;
	}

	//Read solution
	string realsol;
	fstream fin(argv[1]);
	if(!fin)
	{
		cout<<"Couln't open the first file"<<endl;
		//This corrects a BUG in Mooshak: the contents of the file and
		//not the file is passed as arguments
		stringstream ss;
		ss<<argv[1];
		while(1)
		{
			string s, l;
			int ntc;
			ss>>ntc>>l;
			getline(ss, s);
			if(ss.fail())
			{
				cout<<"Reading real solution failed (1)"<<endl;
				return RES_RT_ERROR;
			}
			if(ntc==tc && provsoll==l)
			{
				realsol=s;
				break;
			}
		}
	}
	else
	{
		while(1)
		{
			string s, l;
			int ntc;
			fin>>ntc>>l;
			getline(fin, s);
			if(fin.fail())
			{
				cout<<"Reading real solution failed (2)"<<endl;
				return RES_RT_ERROR;
			}
			if(ntc==tc && provsoll==l)
			{
				realsol=s;
				break;
			}
		}
	}
	if(realsol.length()<1)
	{
		cout<<"No real solution provided"<<endl;
		return RES_RT_ERROR;
	}
	if(realsol.length()>MAX_INPUT_SIZE)
	{
		cout<<"Real solution too long"<<endl;
		return RES_RT_ERROR;
	}

	int mistakes = levenshtein(provsol, realsol);
	double misper = mistakes*100./realsol.length();
	cerr<<mistakes<<" mistakes ("<<misper<<"%)  TC: "<<tc<<" "<<provsoll<<endl;
	if(misper <= TOLERANCE)
		return RES_ACCEPTED;
	return RES_WRONG;
}
