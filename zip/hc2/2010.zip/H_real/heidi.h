#ifndef HC2_HEIDI_H_
#define HC2_HEIDI_H_

/**
  Get the number of interview rounds that will be carried out.
  This function must be the first function you call.
*/
int get_rounds(void);

/**
  Get the number of candidates in the current interview round.
  You must call this function at the start of each interview round.
  You may not call this function again until you called team_up();
*/
int get_N(void);

/**
  Interview the next candidate
  (and reject the previous candidate)
  This function returns the value of the candidate in the range [0;1]
  You must call this function at most N times, after having called get_N();
*/
double interview(void);

/**
  Team up with the candidate you last interviewed.
*/
void team_up(void);

#endif //HC2_HEIDI_H_
