//REAL LIBRARY
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

static int rounds=0;
static int round_i=-1;
static int N=0;
static int N_i=-1;
static int success=0;
static int min_success=0;
static double* candidates=NULL;
static int x_n = 42;
static int init_x_n = 42;
static double rand_min = 0;
static double rand_span = 0;
static int RAND_FUNC=0;

enum States {START, NO_INTERVIEW, INTERVIEW, END};
static enum States state = START;

static double my_rand(void)
{
	const int A = 1664525;
	const int C = 1013904223;
	x_n = A*x_n + C;

	double ret = (x_n & 0x3FFFFFFF)*1.0 / 0x4FFFFFFF;
	assert(ret>=0 && ret<=1);
	switch(RAND_FUNC)
	{
		case 1: ret*=ret; break;
		case 2: ret*=ret*ret; break;
		case 3: ret=sqrt(ret); break;
	}
	return ret*rand_span+rand_min;
}

/**
  Get the number of interview rounds that will be carried out.
  This function must be the first function you call.
*/
int get_rounds(void)
{
	// We expect on standard input:
	//  - Total number of rounds of interview
	//  - Number of candidates (same for all rounds)
	//  - Number of success expected so it returns ACCEPTED
	//  - Seed of the PRNG

	assert(state == START);

	//printf("How many rounds of interview? ");
	assert(scanf("%d" ,&rounds)==1);
	if(rounds<1)
	{
		printf("Illegal number of rounds");
		exit(1);
	}
	//printf("How many candidates? ");
	assert(scanf("%d" ,&N)==1);
	if(N<1)
	{
		printf("Illegal number of candidates");
		exit(1);
	}
	assert(scanf("%d" ,&min_success)==1);
	if(min_success<1)
	{
		printf("Illegal number of min_success");
		exit(1);
	}
	assert(scanf("%d" ,&x_n)==1);
	if(x_n<1)
	{
		printf("Illegal rand seed");
		exit(1);
	}
	init_x_n=x_n;

	state = NO_INTERVIEW;
	return rounds;
}

/**
  Get the number of candidates in the current interview round.
  You must call this function at the start of each interview round.
  You may not call this function again until you called team_up();
*/
int get_N(void)
{
	assert(state == NO_INTERVIEW);
	round_i++;
	if(round_i>=rounds)
	{
		printf("Called get_N() after all interview rounds were over\n");
		exit(1);
	}
	N_i=-1;
	if(candidates==NULL)
		candidates = (double*)malloc(sizeof(double)*N);
	assert(candidates!=NULL);

	RAND_FUNC = round_i%4;
	rand_min=0;rand_span=1;
	double a = my_rand();
	double b = my_rand();
	rand_min = a;
	rand_span = b*(1-a);

	int i;
	for(i=0;i<N;++i)
	{
		candidates[i]=my_rand();
	}
	state = INTERVIEW;
	return N;
}

/**
  Interview the next candidate
  (and reject the previous candidate)
  This function returns the value of the candidate in the range [0;1]
  You must call this function at most N times, after having called get_N();
*/
double interview(void)
{
	assert(state==INTERVIEW);
	assert(candidates!=NULL);
	N_i++;
	if(N_i>=N)
	{
		printf("Called interview() after all interviews were over\n");
		exit(1);
	}
	return candidates[N_i];
}

/**
  Team up with the candidate you last interviewed.
*/
void team_up(void)
{
	assert(state==INTERVIEW);
	assert(candidates!=NULL);
	if(N_i<0 || N_i>=N)
	{
		printf("No candidates to team_up...\n");
		exit(1);
	}
	double max=0;
	int i;
	for(i=0;i<N;++i)
		if(candidates[i]>max)
			max=candidates[i];
	if(candidates[N_i]==max)
		success++;


	if(round_i+1==rounds)
	{
		state = END;

		if(success>=min_success)
		{
			printf("ACCEPTED %d %d %d %d f4b34ad9f53d75b6355156734761dd25\n", rounds, N, min_success, init_x_n);

		}
		else
		{
			printf("FAILED\nRounds where you picked the best candidate: %d (min: %d) / %d\n", success, min_success, rounds);
		}
	}
	else
	{
		state = NO_INTERVIEW;
	}

}
