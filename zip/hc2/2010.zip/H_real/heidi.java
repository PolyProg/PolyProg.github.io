//REAL LIBRARY

import java.util.Scanner;
class Heidi
{
	private static Scanner sc = new Scanner(System.in);
	private static int rounds=0;
	private static int round_i=-1;
	private static int N=0;
	private static int N_i=-1;
	private static int success=0;
	private static int min_success=0;
	private static double[] candidates=null;
	private static int x_n = 42;
	private static int init_x_n = 42;
	private static double rand_min = 0;
	private static double rand_span = 0;
	private static int RAND_FUNC=0;

	private static final int START=0;
	private static final int NO_INTERVIEW=1;
	private static final int INTERVIEW=2;
	private static final int END=3;
	private static int state = START;

	private static double my_rand()
	{
		final int A = 1664525;
		final int C = 1013904223;
		x_n = A*x_n + C;

		double ret = (x_n & 0x3FFFFFFF)*1.0 / 0x4FFFFFFF;
		assert(ret>=0 && ret<=1);
		switch(RAND_FUNC)
		{
			case 1: ret*=ret; break;
			case 2: ret*=ret*ret; break;
			case 3: ret=Math.sqrt(ret); break;
		}
		return ret*rand_span+rand_min;
	}

	/**
	  Get the number of interview rounds that will be carried out.
	  This function must be the first function you call.
	*/
	static int get_rounds()
	{
		// We expect on standard input:
		//  - Total number of rounds of interview
		//  - Number of candidates (same for all rounds)
		//  - Number of success expected so it returns ACCEPTED
		//  - Seed of the PRNG

		assert(state == START);

		//System.out.printf("How many rounds of interview? ");
		rounds = sc.nextInt();
		if(rounds<1)
		{
			System.out.printf("Illegal number of rounds");
			System.exit(1);
		}
		//System.out.printf("How many candidates? ");
		N = sc.nextInt();
		if(N<1)
		{
			System.out.printf("Illegal number of candidates");
			System.exit(1);
		}
		min_success = sc.nextInt();
		if(min_success<1)
		{
			System.out.printf("Illegal number of min_success");
			System.exit(1);
		}
		x_n = sc.nextInt();
		if(x_n<1)
		{
			System.out.printf("Illegal rand seed");
			System.exit(1);
		}
		init_x_n=x_n;

		state = NO_INTERVIEW;
		return rounds;
	}

	/**
	  Get the number of candidates in the current interview round.
	  You must call this function at the start of each interview round.
	  You may not call this function again until you called team_up();
	*/
	static int get_N()
	{
		assert(state == NO_INTERVIEW);
		round_i++;
		if(round_i>=rounds)
		{
			System.out.printf("Called get_N() after all interview rounds were over\n");
			System.exit(1);
		}
		N_i=-1;
		if(candidates==null)
			candidates = new double[N];

		RAND_FUNC = round_i%4;
		rand_min=0;rand_span=1;
		double a = my_rand();
		double b = my_rand();
		rand_min = a;
		rand_span = b*(1-a);

		for(int i=0;i<N;++i)
		{
			candidates[i]=my_rand();
		}
		state = INTERVIEW;
		return N;
	}

	/**
	  Interview the next candidate
	  (and reject the previous candidate)
	  This function returns the value of the candidate in the range [0;1]
	  You must call this function at most N times, after having called get_N();
	*/
	static double interview()
	{
		assert(state==INTERVIEW);
		assert(candidates!=null);
		N_i++;
		if(N_i>=N)
		{
			System.out.printf("Called interview() after all interviews were over\n");
			System.exit(1);
		}
		return candidates[N_i];
	}

	/**
	  Team up with the candidate you last interviewed.
	*/
	static void team_up()
	{
		assert(state==INTERVIEW);
		assert(candidates!=null);
		if(N_i<0 || N_i>=N)
		{
			System.out.printf("No candidates to team_up...\n");
			System.exit(1);
		}
		double max=0;
		for(int i=0;i<N;++i)
			if(candidates[i]>max)
				max=candidates[i];
		if(candidates[N_i]==max)
			success++;

		candidates=null;

		if(round_i+1==rounds)
		{
			state = END;

			if(success>=min_success)
			{
				System.out.printf("ACCEPTED %d %d %d %d f4b34ad9f53d75b6355156734761dd25\n", rounds, N, min_success, init_x_n);

			}
			else
			{
				System.out.printf("FAILED\nRounds where you picked the best candidate: %d (min: %d) / %d\n", success, min_success, rounds);
			}
		}
		else
		{
			state = NO_INTERVIEW;
		}

	}

}
