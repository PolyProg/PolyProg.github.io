#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

static int rounds=0;
static int round_i=-1;
static int N=0;
static int N_i=-1;
static int success=0;
static double* candidates=NULL;

enum States {START, NO_INTERVIEW, INTERVIEW, END};
static enum States state = START;

static double my_rand(void)
{
	static int x_n = 42;
	const int A = 1103515245;
	const int C = 12345;
	x_n = A*x_n + C;

	double ret = (x_n & 0x3FFFFFFF)*1.0 / 0x4FFFFFFF;
	assert(ret>=0 && ret<=1);
	return ret;
}

/**
  Get the number of interview rounds that will be carried out.
  This function must be the first function you call.
*/
int get_rounds(void)
{
	assert(state == START);

	printf("How many rounds of interview? ");
	assert(scanf("%d" ,&rounds)==1);
	if(rounds<1)
	{
		printf("Illegal number of rounds");
		exit(1);
	}
	printf("How many candidates? ");
	assert(scanf("%d" ,&N)==1);
	if(N<1)
	{
		printf("Illegal number of candidates");
		exit(1);
	}

	state = NO_INTERVIEW;
	return rounds;
}

/**
  Get the number of candidates in the current interview round.
  You must call this function at the start of each interview round.
  You may not call this function again until you called team_up();
*/
int get_N(void)
{
	assert(state == NO_INTERVIEW);
	round_i++;
	if(round_i>=rounds)
	{
		printf("Called get_N() after all interview rounds were over\n");
		exit(1);
	}
	N_i=-1;
	assert(candidates==NULL);
	candidates = (double*)malloc(sizeof(double)*N);
	assert(candidates!=NULL);

	int i;
	for(i=0;i<N;++i)
		candidates[i]=my_rand();
	state = INTERVIEW;
	return N;
}

/**
  Interview the next candidate
  (and reject the previous candidate)
  This function returns the value of the candidate in the range [0;1]
  You must call this function at most N times, after having called get_N();
*/
double interview(void)
{
	assert(state==INTERVIEW);
	assert(candidates!=NULL);
	N_i++;
	if(N_i>=N)
	{
		printf("Called interview() after all interviews were over\n");
		exit(1);
	}
	return candidates[N_i];
}

/**
  Team up with the candidate you last interviewed.
*/
void team_up(void)
{
	assert(state==INTERVIEW);
	assert(candidates!=NULL);
	if(N_i<0 || N_i>=N)
	{
		printf("No candidates to team_up...\n");
		exit(1);
	}
	double max=0;
	int i;
	for(i=0;i<N;++i)
		if(candidates[i]>max)
			max=candidates[i];
	if(candidates[N_i]==max)
		success++;

	free(candidates);
	candidates=NULL;

	if(round_i+1==rounds)
	{
		state = END;

		printf("Rounds where you picked the best candidate: %d / %d\n", success, rounds);
		printf("Percentage: %f%%\n", success*100./rounds);
	}
	else
	{
		state = NO_INTERVIEW;
	}

}
