#include "heidi.h"

int main(int argc, char** argv)
{
	int R = get_rounds();
	int r;
	for(r=0;r<R;++r)
	{
		int N = get_N();
		int i;
		for(i=0;i<N;++i)
		{
			double v = interview();
			if( /* some condition*/ v>1 )
				break;
		}
		team_up();
	}
	return 0;
}
