class Sample
{
	public static void main(String args[])
	{
		int R = Heidi.get_rounds();
		for(int r=0;r<R;++r)
		{
			int N = Heidi.get_N();
			for(int i=0;i<N;++i)
			{
				double v = Heidi.interview();
				if( /* some condition*/ false )
					break;
			}
			Heidi.team_up();
		}
	}
}
