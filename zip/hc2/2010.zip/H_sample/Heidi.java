import java.util.Scanner;

class Heidi
{
	private static Scanner sc;
	private static int rounds=0;
	private static int round_i=-1;
	private static int N=0;
	private static int N_i=-1;
	private static int success=0;
	private static double[] candidates=null;

	private final static int START=0;
	private final static int NO_INTERVIEW=1;
	private final static int INTERVIEW=2;
	private final static int END=3;
	private static int state = START;

	private static int x_n=42;

	private static double my_rand()
	{
		final int A = 1103515245;
		final int C = 12345;
		x_n = A*x_n + C;

		double ret = (x_n & 0x3FFFFFFF)*1.0 / 0x4FFFFFFF;
		assert(ret>=0 && ret<=1);
		return ret;
	}

	/**
	  Get the number of interview rounds that will be carried out.
	  This function must be the first function you call.
	*/
	public static int get_rounds()
	{
		assert(state == START);
		assert(sc == null);
		sc = new Scanner(System.in);

		System.out.print("How many rounds of interview? ");
		rounds = sc.nextInt();
		if(rounds<1)
		{
			System.out.print("Illegal number of rounds");
			System.exit(1);
		}
		System.out.print("How many candidates? ");
		N = sc.nextInt();
		if(N<1)
		{
			System.out.print("Illegal number of candidates");
			System.exit(1);
		}

		state = NO_INTERVIEW;
		return rounds;
	}

	/**
	  Get the number of candidates in the current interview round.
	  You must call this function at the start of each interview round.
	  You may not call this function again until you called team_up();
	*/
	public static int get_N()
	{
		assert(state == NO_INTERVIEW);
		round_i++;
		if(round_i>=rounds)
		{
			System.out.print("Called get_N() after all interview rounds were over\n");
			System.exit(1);
		}
		N_i=-1;
		candidates = new double[N];

		for(int i=0;i<N;++i)
			candidates[i]=my_rand();
		state = INTERVIEW;
		return N;
	}

	/**
	  Interview the next candidate
	  (and reject the previous candidate).
	  This function returns the value of the candidate in the range [0;1]
	  You must call this function at most N times, after having called get_N();
	*/
	public static double interview()
	{
		assert(state==INTERVIEW);
		assert(candidates!=null);
		N_i++;
		if(N_i>=N)
		{
			System.out.print("Called interview() after all interviews were over\n");
			System.exit(1);
		}
		return candidates[N_i];
	}

	/**
	  Team up with the candidate you last interviewed.
	*/
	public static void team_up()
	{
		assert(state==INTERVIEW);
		assert(candidates!=null);
		if(N_i<0 || N_i>=N)
		{
			System.out.print("No candidates to team_up...\n");
			System.exit(1);
		}
		double max=0;
		for(int i=0;i<N;++i)
			if(candidates[i]>max)
				max=candidates[i];
		if(candidates[N_i]==max)
			success++;

		candidates=null;

		if(round_i+1==rounds)
		{
			state = END;

			System.out.print("Rounds where you picked the best candidate: "+success+" / "+rounds+"\n");
			System.out.print("Percentage: "+success*100./rounds+"%\n");
		}
		else
		{
			state = NO_INTERVIEW;
		}

	}
}
